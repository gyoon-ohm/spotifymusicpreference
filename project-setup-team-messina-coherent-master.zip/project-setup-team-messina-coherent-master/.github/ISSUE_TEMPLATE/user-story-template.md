---
name: User Story Template
about: A template to use for User Stories
title: ''
labels: user story
assignees: ''

---

## Estimation of work
- TBD

## Acceptance criteria
- [ ] foo
- [ ] bar
- [ ] baz
- [ ] etc
