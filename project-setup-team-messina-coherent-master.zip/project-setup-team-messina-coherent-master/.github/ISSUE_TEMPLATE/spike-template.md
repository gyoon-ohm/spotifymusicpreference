---
name: Spike Template
about: A template to use for Spikes
title: ''
labels: spike
assignees: ''

---

## Estimation of work
- TBD

## Acceptance criteria
- [ ] foo
- [ ] bar
- [ ] etc
- [ ] etc
