import './About_Header.css'
function Headers() {
	return (
    <article className="intro">
      <h1 className="intro-heading">About Page</h1>
      <p className="intro-paragraph">Learn more about our project below</p>
    </article>  
  )
}
export default Headers