import './Privacy_Header.css'
function Headers() {
	return (
    <article className="intro">
      <h1 className="intro-heading">Privacy Policy Page</h1>
      <p className="intro-paragraph">Learn more about our privacy policy below</p>
    </article>  
  )
}
export default Headers