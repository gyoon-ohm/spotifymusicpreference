The initial user experience design of your project will live in this directory by the end of Sprint 0.

Place an exported version of your app prototype into this "prototype" sub-directory.
