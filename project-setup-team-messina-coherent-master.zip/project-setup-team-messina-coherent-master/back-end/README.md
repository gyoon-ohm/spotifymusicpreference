# Running the back end

1. Clone our repository, cd into the back-end folder
2. On the terminal write npm install, which installs all dependencies
3. On the terminal write node app.js
4. In your browser, navigate to https://localhost:3000/by-weather/{zipcode}, inserting your desired zipcode
5. The page will display a json with weather data for the zipcode
6. In your browser, navigate to https://localhost:3000/party
7. The page will give you the json for multiple playlist objects associated with the word party.
8. In your browser, navigate to https://localhost:3000/genre-getter
9. The page will give you the genre of a given song
