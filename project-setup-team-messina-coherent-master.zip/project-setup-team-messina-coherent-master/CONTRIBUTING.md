
Yuval
Ryan
Aisha
Arif
Gi Yoon


#### Team Norms:

All team members will be in EST time zone by the 17th of March.
Each member commits the following weekly meetings:
Meetings on weekends will be coordinated based on need basis and availability.
Meetings will take place on Zoom.

#### Team Values:

Each team member is required to complete his assigned item by the deadline. In case a team member is having difficulty completing his task, he must notify the group no later than the Thursday daily standup, at which point a discussion will be made regatding reassigning the item.
Treat each other with dignity and respect.
Be genuine with each other about ideas, challenges, and feelings.
Listen to understand.
Be open minded.
Don’t be defensive with your about criticism of your work.
Support each other; don't throw each other under the bus.
It's okay to not know the right answer and to admit it.
Present problems in a way that promotes mutual discussion and resolution.
If you commit to doing something, do it.
Respect the time and convenience of others.
For meetings longer than 15 minutes, a designated member will take minutes and publish them for all.
Meetings will start on time.
Members are expected to check and answer questions on Slack daily.

#### Sprint Cadence:

Each sprint will be 2 weeks long

#### Daily Standup:

Monday - 10:30 AM. General daily standup before class to go over the project together.
Thursday - 11:00 AM. Daily standup going over the items due and delegating assignments to each member.
Sunday 9:30. Check-in on prorgress of tasks.
agreement that members will not cover for other members who do not participate.
agreement that a member who makes no progress on a task for two standups or more in a row will be reported to management.

#### Creating Commits:
As a general rule, your messages should start with a single line that’s no more than about 50 characters and that describes the changeset concisely
 

#### Coding standards:

Code Linter ES Lint
Code Editor - VS Code
Don't over-engineer. Write minimum code to get things working end to end, only then iterate to improve. - Code for each task and spike must be peer-reviewed and pass tests before merging into the main branch of code.
Always push working code, if you break the pipeline/build then fix it.
Make granular and small commits, per feature or per bug fix.
Provide descriptive commit messages.
Write self documenting code. Use descriptive variable and function names. Avoid unnecessary name shortening.
Don't leave dead/commented out code behind. If you see such code, delete it.
Write automated tests to cover critical integration points and functionality (once you learn how to do that).


#### TBD:

the Git workflow that the team follows

a detailed description of the rules of contributing and any considerations or how and what to contribute
Rules of contributing:
Each member is responsible for roughly the same ammount of work. 

instructions for setting up the local development environment in order to work on this project

instructions for building and testing the project (update with that information once the project reaches that stage)

This documents allows potential contributors, whether in the open source community or in a private organization, to see the project's rules and processes for contributions. It should be well-formatted with clear headings and subheadings.

GitHub provides a link to this document automatically to any user who creates a Pull Request on this project.
